"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const ddbClient = new client_dynamodb_1.DynamoDBClient({ region: "us-east-1" });
const TABLE_NAME = process.env.DYNAMODB_TABLE;
module.exports.handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    console.log("CREATE PROJECT EVENT: ", event);
    let body;
    let statusCode = 200;
    // TODO: UPDATE TO INCLUDE CORS HEADERS
    const headers = {};
    try {
        if (!JSON.parse(event.body).projectName) {
            throw new SyntaxError("missing project name in body");
        }
        // const id = event.requestContext.authorizer.jwt.claims.sub;
        const projectName = JSON.parse(event.body).projectName;
        const today = new Date();
        // TODO: THINK ON THIS... UPDATING PROJECT NAME BLOWS OUT ALL OTHER FIELDS..
        const params = {
            TableName: TABLE_NAME,
            Item: {
                id: "TODO",
                projectName,
                projectStartDate: today.toISOString(),
                userCompletedSignUpFlow: false,
                userResponseWhatLongForm: "",
                userResponseWhyLongForm: "",
                userResponseSacrificeLongForm: "",
                userResponseHatersLongForm: "",
                weeksExpectedToComplete: "",
                userResponseWhyShortForm: '["","",""]',
                userResponseHatersShortForm: '["","",""]',
                daysResponseFeed: "[]",
            },
        };
        const data = yield ddbClient.send(new lib_dynamodb_1.PutCommand(params));
        return {
            statusCode,
            body: JSON.stringify(data),
            headers,
        };
    }
    catch (err) {
        statusCode = 400;
        body = err.message;
    }
    finally {
        body = JSON.stringify(body);
    }
    return {
        statusCode,
        body,
        headers,
    };
});
