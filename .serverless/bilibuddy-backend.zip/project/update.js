"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const ddbClient = new client_dynamodb_1.DynamoDBClient({ region: "us-east-1" });
const TABLE_NAME = "billibuddy-projects-table";
module.exports.handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    console.log("UPDATE PROJECT EVENT: ", event);
    let body;
    let statusCode = 200;
    const headers = {};
    try {
        const id = event.requestContext.authorizer.jwt.claims.sub;
        const requestJSON = JSON.parse(event.body);
        const { projectToUpdate, fieldToUpdate, updateValue } = requestJSON;
        const validFieldsToUdate = [
            "projectName",
            "projectStartDate",
            "userResponseWhatLongForm",
            "userResponseWhyLongForm",
            "userResponseSacrificeLongForm",
            "userResponseHatersLongForm",
            "weeksExpectedToComplete",
            "userResponseWhyShortForm",
            "userResponseHatersShortForm",
            "daysResponseFeed",
        ];
        if (!validFieldsToUdate.includes(fieldToUpdate)) {
            throw new SyntaxError("Invalid Update Field");
        }
        const updateProjectParams = {
            TableName: TABLE_NAME,
            Key: {
                id,
                projectName: projectToUpdate,
            },
            UpdateExpression: `set ${fieldToUpdate} = :r`,
            ExpressionAttributeValues: {
                ":r": updateValue,
            },
            ReturnValues: "ALL_NEW",
        };
        const completeProjectSetUpParams = {
            TableName: TABLE_NAME,
            Key: {
                id,
                projectName: projectToUpdate,
            },
            UpdateExpression: `set ${fieldToUpdate} = :r, userCompletedSignUpFlow = :k`,
            ExpressionAttributeValues: {
                ":r": updateValue,
                ":k": true,
            },
            ReturnValues: "ALL_NEW",
        };
        // IF USER UPDATES "weeksExpectedToComplete" THEY HAVE COMPLETEED THE SIGN UP FLOW
        const params = fieldToUpdate === "weeksExpectedToComplete"
            ? completeProjectSetUpParams
            : updateProjectParams;
        const data = yield ddbClient.send(new lib_dynamodb_1.UpdateCommand(params));
        console.log("Success :", data);
        body = data;
    }
    catch (err) {
        statusCode = 400;
        body = err.message;
    }
    finally {
        body = JSON.stringify(body);
    }
    return {
        statusCode,
        body,
        headers,
    };
});
